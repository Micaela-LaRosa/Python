from setuptools import setup

setup (
    name="paquete1",
    version="1.0",
    description="First distributed package",
    author="Class 15 - Python",
    author_email="mica.larosa91@gmail.com",

    packages=["paquete1"]
)